const config = {
    owner: ['33189310806@s.whatsapp.net'], // make format nomormu@s.whatsapp.net
};

module.exports = config;
